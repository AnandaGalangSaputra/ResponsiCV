<script setup>
import { RouterView } from 'vue-router';
</script>
<template>
<div class="bg-gray-100 font-sans">
<RouterView />
</div>
</template>