# Interactive CV
Responsi Pemrograman WEB

## Description
A dynamic and interactive CV/Resume website built using Vue js

## Features
- Responsive design
- Interactive elements
- Modern UI/UX
- Easy to customize

## Author
Ananda Galang Saputra

## License
MIT License
