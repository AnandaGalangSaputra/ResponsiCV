const express = require("express");
const cors = require("cors");
const { educationHistory, skills, projects } = require("./data");

const app = express();

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.send("Backend API is running...");
});

app.get("/api/education", (req, res) => res.json(educationHistory));
app.get("/api/skills", (req, res) => res.json(skills));
app.get("/api/projects", (req, res) => res.json(projects));

// Export untuk Vercel handler (tanpa app.listen)
module.exports = app;
module.exports = (req, res) => {
  app(req, res);
};
